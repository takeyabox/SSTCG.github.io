import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
import { getDatabase, ref, set, get, onValue, update, push, child } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-database.js";
import { firebaseConfig } from '../firebase-config.js';

export class FirebaseManager {
    constructor() {
        if (firebaseConfig.apiKey === "YOUR_API_KEY") {
            console.warn("Firebase Config not set!");
            this.db = null;
            return;
        }
        const app = initializeApp(firebaseConfig);
        this.db = getDatabase(app);
        this.roomId = null;
        this.playerId = null;
        this.onGameStateChange = null; // Callback
    }

    async createRoom(roomId, player) {
        if (!this.db) return false;
        const roomRef = ref(this.db, 'rooms/' + roomId);

        // Check if room exists
        const snapshot = await get(roomRef);
        if (snapshot.exists()) {
            throw new Error("Room already exists!");
        }

        const roomData = {
            host: player,
            players: {
                [player.id]: {
                    name: player.name,
                    deck: player.deck,
                    energies: player.energies,
                    ready: true
                }
            },
            status: 'waiting', // waiting, playing, finished
            gameState: null
        };

        await set(roomRef, roomData);
        this.roomId = roomId;
        this.playerId = player.id;
        this.listenToRoom();
        return true;
    }

    async joinRoom(roomId, player) {
        if (!this.db) return false;
        const roomRef = ref(this.db, 'rooms/' + roomId);

        const snapshot = await get(roomRef);
        if (!snapshot.exists()) {
            throw new Error("Room does not exist!");
        }

        const data = snapshot.val();
        if (Object.keys(data.players || {}).length >= 2) {
            throw new Error("Room is full!");
        }

        // Add player
        const playerRef = child(roomRef, 'players/' + player.id);
        await set(playerRef, {
            name: player.name,
            deck: player.deck,
            energies: player.energies,
            ready: true
        });

        this.roomId = roomId;
        this.playerId = player.id;
        this.listenToRoom();
        return true;
    }

    listenToRoom() {
        const roomRef = ref(this.db, 'rooms/' + this.roomId);
        onValue(roomRef, (snapshot) => {
            const data = snapshot.val();
            if (data && this.onGameStateChange) {
                this.onGameStateChange(data);
            }
        });
    }

    async updateGameState(newState) {
        if (!this.roomId || !this.db) return;
        const stateRef = ref(this.db, 'rooms/' + this.roomId + '/gameState');
        await set(stateRef, newState);
    }

    async updateRoomStatus(status) {
        if (!this.roomId || !this.db) return;
        const refLink = ref(this.db, 'rooms/' + this.roomId + '/status');
        await set(refLink, status);
    }

    async startGame(initialState) {
        if (!this.roomId || !this.db) return;
        const updates = {};
        updates['rooms/' + this.roomId + '/status'] = 'playing';
        updates['rooms/' + this.roomId + '/gameState'] = initialState;
        await update(ref(this.db), updates);
    }

    async updateRoom(data) {
        if (!this.roomId || !this.db) return;
        const roomRef = ref(this.db, 'rooms/' + this.roomId);
        await update(roomRef, data);
    }
}
