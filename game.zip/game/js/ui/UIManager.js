export class UIManager {
    constructor(gameEngine, playerId) {
        this.game = gameEngine;
        this.myId = playerId;
        this.elements = {
            log: document.getElementById('battle-log'),
            myActive: document.getElementById('player-active'),
            myBench: document.getElementById('player-bench'),
            myHand: document.getElementById('player-hand'),
            myPrizes: document.getElementById('my-prizes'),
            oppActive: document.getElementById('opponent-active'),
            oppBench: document.getElementById('opponent-bench'),
            oppPrizes: document.getElementById('opp-prizes'),
            energyZone: document.getElementById('generated-energy'),
            turnIndicator: document.getElementById('turn-indicator')
        };

        // Modal
        this.modal = document.getElementById('action-modal');
        document.getElementById('btn-modal-close').onclick = () => this.hideModal();
    }

    render(gameState) {
        if (!gameState) return;

        console.log("=== UIManager.render DEBUG ===");
        console.log("My ID:", this.myId);

        const myPlayer = this.game.getPlayer(this.myId);
        const oppPlayer = this.game.getOpponent(this.myId);

        console.log("My player:", myPlayer.id, myPlayer.name, "Hand:", JSON.stringify(myPlayer.handIds));
        console.log("Opp player:", oppPlayer.id, oppPlayer.name, "Hand:", JSON.stringify(oppPlayer.handIds));

        this.updateLog(this.game.battleLog);
        this.renderHand(myPlayer.handIds);
        this.renderField(myPlayer, this.elements.myActive, this.elements.myBench, true);
        this.renderField(oppPlayer, this.elements.oppActive, this.elements.oppBench, false);

        // Render Prizes
        this.renderPrizes(myPlayer.prizes, this.elements.myPrizes, true);
        this.renderPrizes(oppPlayer.prizes, this.elements.oppPrizes, false);

        this.elements.myPrizes.textContent = myPlayer.prizes;
        this.elements.oppPrizes.textContent = oppPlayer.prizes;

        const isMyTurn = this.game.currentTurnPlayerId === this.myId;
        const isSetupPhase = this.game.phase === 'setup';

        // Update turn indicator based on phase
        if (isSetupPhase) {
            if (myPlayer.setupReady) {
                this.elements.turnIndicator.textContent = "準備完了 - 相手を待っています...";
            } else {
                this.elements.turnIndicator.textContent = "セットアップ中";
            }
        } else {
            this.elements.turnIndicator.textContent = isMyTurn ? "あなたのターン" : "相手のターン";
        }

        // Setup Ready Button
        const btnSetupReady = document.getElementById('btn-setup-ready');
        if (btnSetupReady) {
            if (isSetupPhase) {
                btnSetupReady.style.display = myPlayer.setupReady ? 'none' : 'block';
                btnSetupReady.disabled = !myPlayer.active; // Need at least active Pokemon
                btnSetupReady.onclick = () => {
                    try {
                        this.game.markSetupReady(this.myId);
                        if (this.onAction) this.onAction();
                    } catch (e) {
                        alert(e.message);
                    }
                };
            } else {
                btnSetupReady.style.display = 'none';
            }
        }

        // Regular game buttons
        document.getElementById('btn-draw').disabled = !isMyTurn || this.game.phase !== 'turn_start';
        document.getElementById('btn-attack').disabled = !isMyTurn || this.game.phase !== 'main';
        const canRetreat = isMyTurn && this.game.phase === 'main' && myPlayer.active && myPlayer.bench.length > 0;
        document.getElementById('btn-retreat').disabled = !canRetreat;
        document.getElementById('btn-retreat').onclick = () => {
            if (confirm("ベンチの先頭のポケモンと交代しますか？")) {
                try {
                    this.game.switchPokemon(this.myId, 0);
                    if (this.onAction) this.onAction();
                } catch (e) { alert(e.message); }
            }
        };

        document.getElementById('btn-end-turn').disabled = !(isMyTurn && this.game.phase === 'main');
        document.getElementById('btn-end-turn').onclick = () => {
            this.game.endTurn();
            if (this.onAction) this.onAction();
        };

        // Energy Zone
        this.elements.energyZone.innerHTML = '';
        myPlayer.energyZone.forEach(e => {
            const span = document.createElement('span');
            span.textContent = e;
            span.className = `energy-icon ${e.toLowerCase()}`;
            this.elements.energyZone.appendChild(span);
        });
    }

    renderHand(handIds) {
        this.elements.myHand.innerHTML = '';
        handIds.forEach((cardId, index) => {
            const card = this.game.getCardData(cardId);
            if (!card) {
                console.error("Card not found:", cardId);
                return;
            }
            const el = this.createCardElement(card);

            // Store cardId in dataset to ensure fresh value on interaction
            el.dataset.cardId = cardId;
            el.dataset.cardIndex = index;

            // Double-click: Place directly on active field (or bench if active is filled)
            // Single-click: Show modal for placement options
            let clickTimeout;

            el.ondblclick = (event) => {
                // Cancel any pending single-click action
                if (clickTimeout) {
                    clearTimeout(clickTimeout);
                    clickTimeout = null;
                }
                // Read cardId from dataset to ensure fresh value
                const freshCardId = parseInt(event.currentTarget.dataset.cardId);
                const freshCard = this.game.getCardData(freshCardId);
                this.handleCardDoubleClick(freshCardId, freshCard);
            };

            el.onclick = (event) => {
                // Reset timer on each click (debounce/wait for dblclick)
                if (clickTimeout) {
                    clearTimeout(clickTimeout);
                }

                clickTimeout = setTimeout(() => {
                    // Read cardId from dataset to ensure fresh value
                    const freshCardId = parseInt(event.currentTarget.dataset.cardId);
                    const freshIndex = parseInt(event.currentTarget.dataset.cardIndex);
                    this.handleCardClick(freshCardId, freshIndex);
                    clickTimeout = null;
                }, 250); // Wait 250ms to see if double-click happens
            };

            this.elements.myHand.appendChild(el);
        });
    }

    handleCardDoubleClick(cardId, cardData) {
        console.log("=== DOUBLE CLICK DEBUG ===");
        console.log("Card ID received:", cardId, "Type:", typeof cardId);
        console.log("Card data:", cardData.name, "Stage:", cardData.stage);

        // During setup phase, both players can place Pokemon
        // During normal play, check if it's my turn
        const isSetupPhase = this.game.phase === 'setup';
        if (!isSetupPhase && this.game.currentTurnPlayerId !== this.myId) {
            alert("相手のターンです！");
            return;
        }

        // In setup phase, only allow if not already ready
        if (isSetupPhase) {
            const myPlayer = this.game.getPlayer(this.myId);
            if (myPlayer.setupReady) {
                alert("既に準備完了しています！");
                return;
            }
        }

        if (!cardData) {
            alert("カードが見つかりません");
            return;
        }

        const myPlayer = this.game.getPlayer(this.myId);
        console.log("My hand IDs:", myPlayer.handIds, "Types:", myPlayer.handIds.map(id => typeof id));

        // Only handle Basic Pokemon for double-click
        if (cardData.stage === 'Basic') {
            try {
                // Try to place on active first, then bench
                if (!myPlayer.active) {
                    console.log("Attempting to place on Active...");
                    this.game.playBasicPokemon(this.myId, cardId, -1);
                    console.log("Placed on Active via double-click!");
                } else if (myPlayer.bench.length < 3) {
                    console.log("Attempting to place on Bench...");
                    this.game.playBasicPokemon(this.myId, cardId, 0);
                    console.log("Placed on Bench via double-click!");
                } else {
                    alert("場がいっぱいです！");
                    return;
                }

                if (this.onAction) this.onAction();
            } catch (e) {
                console.error("Failed to place via double-click:", e);
                alert(e.message);
            }
        } else {
            // For evolution cards, show modal
            this.handleCardClick(cardId, 0);
        }
    }

    renderField(player, activeContainer, benchContainer, isMe) {
        activeContainer.innerHTML = '';
        if (player.active) {
            // isMe means !isOpponent. If I am renderField(..., isMe=true), then isOpponent=false.
            // Wait, previous call: renderField(myPlayer, ..., true). So 4th arg is isMe.
            const el = this.createCardElement(player.active.data, player.active, !isMe);
            if (isMe) el.onclick = () => this.handleActiveClick();
            activeContainer.appendChild(el);
        }

        benchContainer.innerHTML = '';
        player.bench.forEach((p, i) => {
            const el = this.createCardElement(p.data, p, !isMe);
            if (isMe) el.onclick = () => this.handleBenchClick(i);
            benchContainer.appendChild(el);
        });
    }

    createCardElement(cardData, pokemonInstance = null, isOpponent = false) {
        const div = document.createElement('div');
        div.className = 'card';

        // Handle Face Down (Opponent's setup cards or Prizes)
        // If it's a Pokemon instance and has isFaceDown=true
        // AND it belongs to opponent, show card back.
        // Or if it's a raw card data (like hand) but we shouldn't be seeing it? 
        // (Hand logic is handled by not rendering opp hand at all usually, or just backs)

        const isFaceDown = pokemonInstance && pokemonInstance.isFaceDown;

        if (isFaceDown && isOpponent) {
            div.className += ' card-back';
            div.textContent = 'CARD'; // Placeholder for back art
            return div;
        }

        // Logic for My Face-Down cards (show transparently or with icon?)
        if (isFaceDown && !isOpponent) {
            div.classList.add('face-down-mine'); // CSS to make it look semi-transparent or "hidden" style
        }

        div.classList.add(cardData.isEx ? 'ex' : 'normal');
        div.style.borderTop = `4px solid var(--color-${cardData.type ? 'accent' : 'text'})`;

        // If pokemonInstance, show HP/Energy
        let content = `<div class="name">${cardData.name}</div>`;
        if (pokemonInstance) {
            content += `<div class="hp">${pokemonInstance.currentHp}/${pokemonInstance.maxHp}</div>`;
            const energyText = pokemonInstance.energies.map(e => e[0]).join('');
            content += `<div class="energies">${energyText}</div>`;
        } else {
            content += `<div class="hp">${cardData.hp} HP</div>`;
        }

        if (isFaceDown && !isOpponent) {
            content += `<div class="status-badge">Set (Hidden)</div>`;
        }

        div.innerHTML = content;
        return div;
    }

    updateLog(logs) {
        // Just show last 5? or all.
        this.elements.log.innerHTML = logs.slice(-5).join('<br>'); // Simple log
    }

    renderPrizes(prizeCards, container, isMe) {
        container.innerHTML = '';
        // prizeCards is array of IDs or objects? GameEngine changed it to IDs.
        // Wait, restoreState logic: "this.player.prizes = playerData.prizes || ..." which might be IDs.
        // Let's assume IDs.

        // For render, we just show a card back for each prize.
        if (!Array.isArray(prizeCards) && typeof prizeCards === 'number') {
            // Legacy support
            container.textContent = `Prizes: ${prizeCards}`;
            return;
        }

        prizeCards.forEach(cardId => {
            const div = document.createElement('div');
            div.className = 'card card-back prize-card';
            // div.textContent = 'Prize';
            container.appendChild(div);
        });
    }

    // Interactions
    handleCardClick(cardId, index) {
        // During setup phase, both players can place Pokemon
        // During normal play, check if it's my turn
        const isSetupPhase = this.game.phase === 'setup';
        if (!isSetupPhase && this.game.currentTurnPlayerId !== this.myId) {
            alert("相手のターンです！");
            return;
        }

        // In setup phase, only allow if not already ready
        if (isSetupPhase) {
            const myPlayer = this.game.getPlayer(this.myId);
            if (myPlayer.setupReady) {
                alert("既に準備完了しています！");
                return;
            }
        }

        const cardData = this.game.getCardData(cardId);
        if (!cardData) {
            alert("カードが見つかりません");
            return;
        }

        // Handle Basic Pokemon
        if (cardData.stage === 'Basic') {
            this.showPlacementModal(cardId, cardData);
        } else {
            // Evolution only during normal play, not setup
            if (isSetupPhase) {
                alert("セットアップフェーズでは進化できません");
                return;
            }

            // Try to evolve active Pokemon
            const myPlayer = this.game.getPlayer(this.myId);
            if (myPlayer.active && myPlayer.active.name === cardData.evolutionFrom) {
                try {
                    this.game.evolvePokemon(this.myId, myPlayer.active, cardId);
                    if (this.onAction) this.onAction();
                } catch (e) {
                    alert(e.message);
                }
            } else {
                alert(`進化元: ${cardData.evolutionFrom} のポケモンが場にいません`);
            }
        }
    }

    showPlacementModal(cardId, cardData) {
        console.log("Showing placement modal for:", cardData.name, "ID:", cardId);

        this.modal.classList.remove('hidden');
        const body = document.getElementById('modal-body');
        const title = document.getElementById('modal-title');
        title.textContent = `${cardData.name} を場に出す`;
        body.innerHTML = '';

        const myPlayer = this.game.getPlayer(this.myId);

        // Option: Place as Active
        if (!myPlayer.active) {
            const btnActive = document.createElement('button');
            btnActive.className = 'btn primary';
            btnActive.textContent = 'バトル場に出す';
            btnActive.onclick = () => {
                console.log("Placing on Active field...");
                try {
                    this.game.playBasicPokemon(this.myId, cardId, -1);
                    console.log("Successfully placed on Active!");
                    if (this.onAction) this.onAction();
                    this.hideModal();
                } catch (e) {
                    console.error("Failed to place on Active:", e);
                    alert(e.message);
                }
            };
            body.appendChild(btnActive);
        }

        // Option: Place on Bench
        if (myPlayer.bench.length < 3) {
            const btnBench = document.createElement('button');
            btnBench.className = 'btn secondary';
            btnBench.textContent = `ベンチに出す (${myPlayer.bench.length}/3)`;
            btnBench.onclick = () => {
                console.log("Placing on Bench...");
                try {
                    this.game.playBasicPokemon(this.myId, cardId, 0);
                    console.log("Successfully placed on Bench!");
                    if (this.onAction) this.onAction();
                    this.hideModal();
                } catch (e) {
                    console.error("Failed to place on Bench:", e);
                    alert(e.message);
                }
            };
            body.appendChild(btnBench);
        }

        // If no valid placement
        if (body.children.length === 0) {
            body.innerHTML = '<p>場がいっぱいです！</p>';
        }

        console.log("Modal ready, options:", body.children.length);
    }

    handleActiveClick() {
        // Select for attack or retreat?
        if (this.game.currentTurnPlayerId !== this.myId) return;
        // Show attack modal
        this.showAttackModal();
    }

    handleBenchClick(benchIndex) {
        // Future: Show modal to switch, attach energy, etc.
        // For now, show info
        const myPlayer = this.game.getPlayer(this.myId);
        const benchPoke = myPlayer.bench[benchIndex];
        if (benchPoke) {
            console.log("Bench Pokemon:", benchPoke.name, benchPoke.currentHp + "/" + benchPoke.maxHp);
        }
    }

    showAttackModal() {
        // Show moves of active pokemon
        const active = this.game.player.active;
        if (!active) return;

        this.modal.classList.remove('hidden');
        const body = document.getElementById('modal-body');
        body.innerHTML = '';

        active.data.moves.forEach((move, i) => {
            const btn = document.createElement('button');
            btn.className = 'btn secondary';
            btn.textContent = `${move.cost.join('')} - Damage: ${move.damage}`;
            btn.onclick = () => {
                this.game.attack(this.myId, i);
                if (this.onAction) this.onAction();
                this.hideModal();
            };
            body.appendChild(btn);
        });
    }

    hideModal() {
        this.modal.classList.add('hidden');
    }
}
