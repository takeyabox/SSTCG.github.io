import { CARDS } from '../data/cards.js';

export class Pokemon {
    constructor(cardId) {
        const cardData = CARDS.find(c => c.id === cardId);
        if (!cardData) throw new Error(`Card ${cardId} not found`);

        this.id = cardId; // Card ID reference
        this.data = cardData; // Static data
        this.name = cardData.name;
        this.maxHp = cardData.hp;
        this.currentHp = cardData.hp;
        this.energies = []; // Array of types e.g., ["Fire", "Water"]
        this.status = null; // null, "Poison", "Burn", "Paralysis", "Sleep", "Confusion"
        this.stages = 0; // 0 = Basic, 1 = Stage 1, etc.
        this.turnPlayed = 0; // Turn number when played (for evolution check)
        this.damageTakenHistory = []; // For specific effects

        // Dynamic flags
        this.canAttack = true;
        this.canRetreat = true;
        this.isFaceDown = false; // New flag for setup phase
    }

    takeDamage(amount) {
        // Apply abilities like "Splash Shield" (-20 dmg) or "Stealth"
        let finalDamage = amount;

        if (this.data.ability && this.data.ability.name === "スプラッシュシールド") {
            finalDamage -= 20;
        }
        if (this.data.ability && this.data.ability.name === "潜伏" && this.currentHp === this.maxHp) {
            finalDamage -= 40;
        }

        if (finalDamage < 0) finalDamage = 0;
        this.currentHp -= finalDamage;
        return finalDamage;
    }

    attachEnergy(type) {
        this.energies.push(type);
    }

    heal(amount) {
        this.currentHp = Math.min(this.currentHp + amount, this.maxHp);
    }

    toJSON() {
        return {
            id: this.id,
            currentHp: this.currentHp,
            energies: this.energies,
            status: this.status,
            stages: this.stages,
            turnPlayed: this.turnPlayed,
            canAttack: this.canAttack,
            canRetreat: this.canRetreat,
            isFaceDown: this.isFaceDown
        };
    }

    static fromData(data) {
        if (!data) return null;
        const p = new Pokemon(data.id);
        p.currentHp = data.currentHp;
        p.energies = data.energies || [];
        p.status = data.status;
        p.stages = data.stages || 0;
        p.turnPlayed = data.turnPlayed || 0;
        p.canAttack = data.canAttack !== undefined ? data.canAttack : true;
        p.canRetreat = data.canRetreat !== undefined ? data.canRetreat : true;
        p.isFaceDown = data.isFaceDown || false;
        return p;
    }
}

export class Player {
    constructor(id, name, deckIds, selectedEnergyTypes) {
        this.id = id;
        this.name = name;
        this.deckIds = [...deckIds]; // Array of card IDs
        this.handIds = [];

        this.active = null; // Pokemon object
        this.bench = []; // Array of Pokemon objects (max 3)
        this.prizes = 0; // Number of prizes taken
        this.energyZone = []; // Available energy for this turn
        this.selectedEnergyTypes = selectedEnergyTypes;
        this.setupReady = false; // Ready flag for setup phase

        this.discardPile = [];
    }

    toJSON() {
        return {
            id: this.id,
            name: this.name,
            deckIds: this.deckIds,
            handIds: this.handIds,
            active: this.active ? this.active.toJSON() : null,
            bench: this.bench.map(b => b.toJSON()),
            prizes: this.prizes,
            energyZone: this.energyZone,
            selectedEnergyTypes: this.selectedEnergyTypes,
            discardPile: this.discardPile,
            setupReady: this.setupReady || false
        };
    }

    static fromData(data) {
        if (!data) return null;
        const p = new Player(data.id, data.name, data.deckIds || [], data.selectedEnergyTypes || []);
        p.handIds = data.handIds || [];
        p.prizes = data.prizes || 0;
        p.energyZone = data.energyZone || [];
        p.discardPile = data.discardPile || [];
        p.setupReady = data.setupReady || false;

        if (data.active) p.active = Pokemon.fromData(data.active);
        if (data.bench) p.bench = data.bench.map(b => Pokemon.fromData(b));

        return p;
    }

    draw(count = 1) {
        for (let i = 0; i < count; i++) {
            if (this.deckIds.length > 0) {
                const cardId = this.deckIds.pop();
                this.handIds.push(cardId);
            }
        }
    }

    shuffleDeck() {
        for (let i = this.deckIds.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [this.deckIds[i], this.deckIds[j]] = [this.deckIds[j], this.deckIds[i]];
        }
    }

    generateEnergy() {
        if (this.selectedEnergyTypes.length === 0) return;
        const type = this.selectedEnergyTypes[Math.floor(Math.random() * this.selectedEnergyTypes.length)];
        this.energyZone.push(type);
        return type;
    }
}

export class GameEngine {
    constructor(playerId, opponentId, playerDeck, opponentDeck, playerEnergies, opponentEnergies) {
        this.turnCount = 1;
        this.currentTurnPlayerId = null; // Will be set after coin toss
        this.phase = 'setup'; // setup, turn_start, main, attack, end

        this.player = new Player(playerId, "You", playerDeck, playerEnergies);
        this.opponent = new Player(opponentId, "Opponent", opponentDeck, opponentEnergies);

        this.battleLog = [];
    }

    log(message) {
        this.battleLog.push(message);
        // Dispatch event for UI
    }

    toJSON() {
        return {
            turnCount: this.turnCount,
            currentTurnPlayerId: this.currentTurnPlayerId,
            phase: this.phase,
            battleLog: this.battleLog,
            players: {
                [this.player.id]: this.player.toJSON(),
                [this.opponent.id]: this.opponent.toJSON()
            }
        };
    }

    restoreState(data) {
        if (!data) return;

        console.log("=== restoreState DEBUG ===");
        this.turnCount = data.turnCount;
        this.currentTurnPlayerId = data.currentTurnPlayerId;
        this.phase = data.phase;
        this.battleLog = data.battleLog || [];

        // Restore Players
        if (data.players) {
            // Update this.player (Local Player)
            if (data.players[this.player.id]) {
                const playerData = data.players[this.player.id];

                // CRITICAL: Only sync private data (hand/deck) if ours is empty (initial load)
                if (this.player.handIds.length === 0 && playerData.handIds && playerData.handIds.length > 0) {
                    console.log("Restoring local hand from server:", playerData.handIds);
                    this.player.handIds = playerData.handIds;
                }
                if (this.player.deckIds.length === 0 && playerData.deckIds && playerData.deckIds.length > 0) {
                    this.player.deckIds = playerData.deckIds;
                }

                // Public Properties - Always Sync
                this.player.prizes = playerData.prizes || 0;
                this.player.energyZone = playerData.energyZone || [];
                this.player.discardPile = playerData.discardPile || [];
                this.player.setupReady = playerData.setupReady || false;

                // Restore Board State
                if (playerData.active) this.player.active = Pokemon.fromData(playerData.active);
                this.player.bench = (playerData.bench || []).map(b => Pokemon.fromData(b));
            }

            // Update this.opponent (Remote Player) - Sync Everything available
            if (data.players[this.opponent.id]) {
                const opponentData = data.players[this.opponent.id];
                this.opponent.handIds = opponentData.handIds || [];
                this.opponent.deckIds = opponentData.deckIds || [];
                this.opponent.prizes = opponentData.prizes || 0;
                this.opponent.energyZone = opponentData.energyZone || [];
                this.opponent.discardPile = opponentData.discardPile || [];
                this.opponent.setupReady = opponentData.setupReady || false;

                if (opponentData.active) this.opponent.active = Pokemon.fromData(opponentData.active);
                this.opponent.bench = (opponentData.bench || []).map(b => Pokemon.fromData(b));
            }
        }
    }

    // --- Setup Phase ---
    initGame() {
        // Shuffle decks
        this.player.shuffleDeck();
        this.opponent.shuffleDeck();

        // Draw Initial Hand (5 cards) with mulligan
        this.drawInitialHand(this.player);
        this.drawInitialHand(this.opponent);

        // Setup Prizes (3 cards)
        this.setupPrizes(this.player);
        this.setupPrizes(this.opponent);

        // Determine first player (coin toss)
        const coinToss = Math.random() > 0.5;
        this.currentTurnPlayerId = coinToss ? this.player.id : this.opponent.id;
        this.log(`コイントス: ${coinToss ? this.player.name : this.opponent.name} が先攻！`);

        // Start in setup phase
        this.phase = 'setup';
        this.log(`セットアップ開始: 手札5枚, サイド3枚`);
        this.log(`バトル場とベンチにポケモンを配置してください`);
    }

    setupPrizes(player) {
        // Changed from 6 to 3 prizes
        for (let i = 0; i < 3; i++) {
            if (player.deckIds.length > 0) {
                player.deckIds.pop(); // Remove from deck (prizes not tracked as cards)
            }
        }
    }

    drawInitialHand(player) {
        let hasBasic = false;
        let mulliganCount = 0;

        while (!hasBasic) {
            // Reset if mulligan
            if (mulliganCount > 0) {
                this.log(`${player.name} はたねポケモンがいないためマリガン (${mulliganCount}回目)`);
                // Return hand to deck
                player.deckIds.push(...player.handIds);
                player.handIds = [];
                player.shuffleDeck();
            }

            // Changed from 7 to 5 cards
            player.draw(5);

            // Check for Basic
            hasBasic = player.handIds.some(id => {
                const card = CARDS.find(c => c.id == id); // Loose equality for safety
                return card && card.stage === 'Basic';
            });

            if (!hasBasic) {
                mulliganCount++;
                if (mulliganCount > 10) {
                    console.error("Infinite Mulligan Detected - forcing basics");
                    // Failsafe: search deck for a basic and force draw it
                    const basicIndex = player.deckIds.findIndex(id => CARDS.find(c => c.id == id).stage === 'Basic');
                    if (basicIndex !== -1) {
                        const basicId = player.deckIds.splice(basicIndex, 1)[0];
                        player.handIds.push(basicId);
                        player.draw(4); // Draw rest (total 5)
                        hasBasic = true;
                    } else {
                        throw new Error("Deck has no Basic Pokemon!");
                    }
                }
            }
        }
    }

    // Called when a player marks themselves as ready in setup
    markSetupReady(playerId) {
        const player = this.getPlayer(playerId);

        // Check if player has at least one active Pokemon
        if (!player.active) {
            throw new Error("バトル場にポケモンを配置してください！");
        }

        player.setupReady = true;
        this.log(`${player.name} の準備が完了しました`);

        // Check if both players are ready
        if (this.player.setupReady && this.opponent.setupReady) {
            this.log(`両者準備完了！ 対戦開始！`);
            this.revealSetupPokemon();
            this.startTurn(this.currentTurnPlayerId);
        }
    }

    revealSetupPokemon() {
        // Flip all pokemon face up
        [this.player, this.opponent].forEach(p => {
            if (p.active) p.active.isFaceDown = false;
            p.bench.forEach(b => b.isFaceDown = false);
        });
        this.log("ポケモンが表になりました！");
    }

    // --- Turn Management ---
    startTurn(playerId) {
        this.currentTurnPlayerId = playerId;
        this.phase = 'turn_start';
        const activePlayer = this.getPlayer(playerId);

        // 1. Draw Card
        activePlayer.draw(1);
        this.log(`${activePlayer.name} はカードを引いた。`);

        // 2. Generate Energy
        const energy = activePlayer.generateEnergy();
        this.log(`エネルギーゾーンに ${energy} が発生！`);

        this.phase = 'main';
    }

    // --- Actions ---
    playBasicPokemon(playerId, cardId, slotIndex = -1) {
        // slotIndex -1 = Active, 0-2 = Bench
        console.log("=== playBasicPokemon DEBUG ===");
        console.log("PlayerId:", playerId);
        console.log("this.player.id:", this.player.id, "this.opponent.id:", this.opponent.id);

        const player = this.getPlayer(playerId);
        console.log("Selected player:", player.id, "player.name:", player.name);
        console.log("Player hand IDs:", JSON.stringify(player.handIds));

        // Helper to normalize IDs for comparison
        const normalizeId = (id) => (typeof id === 'string' ? parseInt(id) : id);
        const numericCardId = normalizeId(cardId);

        console.log("Looking for card ID:", numericCardId, "(original:", cardId, ")");

        const cardIndex = player.handIds.findIndex(id => normalizeId(id) === numericCardId);

        if (cardIndex === -1) {
            console.error("❌ Card not found in hand!");
            console.error("Requested CardId:", numericCardId);
            console.error("Hand contains:", JSON.stringify(player.handIds));
            throw new Error("手札にありません");
        }

        console.log("✓ Card found at index:", cardIndex);

        const cardData = CARDS.find(c => c.id === numericCardId);
        if (!cardData) {
            console.error("Card data not found for ID:", numericCardId);
            throw new Error("カードデータが見つかりません");
        }

        if (cardData.stage !== 'Basic') throw new Error("たねポケモンではありません");

        const newPokemon = new Pokemon(numericCardId);
        newPokemon.turnPlayed = this.turnCount;

        // Setup Phase: Place Face Down
        if (this.phase === 'setup') {
            newPokemon.isFaceDown = true;
        }

        if (slotIndex === -1) {
            if (player.active) throw new Error("バトル場は既に埋まっています");
            player.active = newPokemon;
        } else {
            if (player.bench.length >= 3) throw new Error("ベンチがいっぱいです");
            player.bench.push(newPokemon);
        }

        // Remove from hand
        player.handIds.splice(cardIndex, 1);
        this.log(`${player.name} は ${cardData.name} を出した。`);
    }

    evolvePokemon(playerId, targetPokemon, cardId) {
        const player = this.getPlayer(playerId);

        // Ensure cardId is a number for comparison
        const numericCardId = typeof cardId === 'string' ? parseInt(cardId) : cardId;

        const cardIndex = player.handIds.findIndex(id => {
            const numericHandId = typeof id === 'string' ? parseInt(id) : id;
            return numericHandId === numericCardId;
        });

        if (cardIndex === -1) throw new Error("手札にありません");

        const cardData = CARDS.find(c => c.id === numericCardId);

        // Validate Evo
        if (cardData.evolutionFrom !== targetPokemon.name) throw new Error("進化元が違います");
        if (this.turnCount <= targetPokemon.turnPlayed) throw new Error("出したばかりのポケモンは進化できません");

        // Evolve
        targetPokemon.id = numericCardId;
        targetPokemon.data = cardData; // Update data reference
        targetPokemon.name = cardData.name;
        targetPokemon.maxHp = cardData.hp;
        // HP stays the same, max increases
        targetPokemon.stages += 1;

        player.handIds.splice(cardIndex, 1);
        this.log(`${player.name} は ${cardData.name} に進化した！`);
    }

    attachEnergy(playerId, pokemon, energyType) {
        const player = this.getPlayer(playerId);
        const energyIndex = player.energyZone.indexOf(energyType);
        if (energyIndex === -1) throw new Error("エネルギーゾーンにそのエネルギーはありません");

        pokemon.attachEnergy(energyType);
        player.energyZone.splice(energyIndex, 1);
        this.log(`${player.name} は ${pokemon.name} に ${energyType} エネルギーをつけた。`);
    }

    // Check if Pokemon has enough energy to use a move
    canUseMove(pokemon, move) {
        if (!move || !move.cost) return false;

        const cost = move.cost;
        const energies = [...pokemon.energies]; // Copy to avoid mutation

        // Count each type needed
        for (const requiredType of cost) {
            if (requiredType === "Colorless") {
                // Colorless can be satisfied by any energy
                if (energies.length > 0) {
                    energies.pop(); // Remove any energy
                } else {
                    return false;
                }
            } else {
                // Specific type required
                const idx = energies.indexOf(requiredType);
                if (idx !== -1) {
                    energies.splice(idx, 1);
                } else {
                    return false;
                }
            }
        }

        return true;
    }

    attack(playerId, moveIndex) {
        const player = this.getPlayer(playerId);
        const opponent = this.getOpponent(playerId);
        const activeDef = opponent.active;
        const activeAtk = player.active;

        if (!activeAtk) throw new Error("バトル場のポケモンがいません");
        if (!activeDef) throw new Error("相手のバトル場にポケモンがいません");

        // Status Checks
        if (activeAtk.status === 'Sleep' || activeAtk.status === 'Paralysis') {
            throw new Error("状態異常で攻撃できません");
        }
        if (activeAtk.status === 'Confusion') {
            const flip = Math.random() > 0.5;
            if (!flip) {
                this.log(`${activeAtk.name} はこんらんして技が失敗した！(ターン終了)`);
                this.endTurn();
                return;
            }
            this.log(`${activeAtk.name} は正気に戻った！`);
        }

        const move = activeAtk.data.moves[moveIndex];
        if (!move) throw new Error("技がありません");

        // Check Energy Cost
        if (!this.canUseMove(activeAtk, move)) {
            throw new Error("エネルギーが足りません");
        }

        // Calculate Damage
        let damage = move.damage || 0;

        // Apply move effects
        damage = this.applyMoveEffects(move, activeAtk, activeDef, player, opponent, damage);

        // Weakness Check
        if (activeAtk.data.type === activeDef.data.weakness) {
            damage *= 2;
            this.log("こうかはばつぐんだ！");
        }

        // Apply Damage to active defender
        if (damage > 0) {
            const dmgTaken = activeDef.takeDamage(damage);
            this.log(`${activeAtk.name} の攻撃！ ${dmgTaken} ダメージを与えた。`);
        }

        // Check KO
        if (activeDef.currentHp <= 0) {
            this.handleKnockout(opponent, activeDef);
            player.prizes += activeDef.data.isEx ? 2 : 1;
            this.log(`${opponent.name} の ${activeDef.name} は倒れた！ ${player.name} はサイドを${activeDef.data.isEx ? 2 : 1}ポイント取った。`);
            opponent.active = null; // Needs replacement

            // Changed from 6 to 3
            if (player.prizes >= 3) {
                this.log(`${player.name} の勝利！`);
                this.phase = "game_over";
                return;
            }
        }

        this.endTurn();
    }

    applyMoveEffects(move, attacker, defender, attackingPlayer, defendingPlayer, baseDamage) {
        let totalDamage = baseDamage;

        if (!move.effectType || move.effectType === 'none') {
            return totalDamage;
        }

        switch (move.effectType) {
            case 'bench_damage':
                // Deal damage to a bench Pokemon
                if (defendingPlayer.bench.length > 0) {
                    const target = defendingPlayer.bench[0]; // Simplified: target first bench
                    target.takeDamage(move.effectValue);
                    this.log(`ベンチの ${target.name} に ${move.effectValue} ダメージ！`);
                }
                break;

            case 'snipe':
                // Choose any opponent Pokemon to damage
                // For now, target active (UI would allow selection)
                totalDamage = move.damageValue || 0;
                break;

            case 'random_sniping':
                // Hit random Pokemon multiple times
                const allTargets = [defendingPlayer.active, ...defendingPlayer.bench].filter(p => p);
                for (let i = 0; i < move.times; i++) {
                    if (allTargets.length > 0) {
                        const target = allTargets[Math.floor(Math.random() * allTargets.length)];
                        target.takeDamage(move.damagePerHit);
                    }
                }
                totalDamage = 0; // Already dealt damage
                break;

            case 'coin_flip_damage':
                let heads = 0;
                for (let i = 0; i < move.coinCount; i++) {
                    if (Math.random() > 0.5) heads++;
                }
                this.log(`コイントス: ${heads}回オモテ！`);
                totalDamage += heads * move.damagePerHead;
                break;

            case 'damage_plus_if_ex':
                if (defender.data.isEx) {
                    totalDamage += move.effectValue;
                    this.log(`相手はEX！ ${move.effectValue} ダメージ追加！`);
                }
                break;

            case 'heal_self':
                attacker.heal(move.healAmount);
                this.log(`${attacker.name} は ${move.healAmount} HP回復した！`);
                break;

            case 'discard_energy':
                // Discard energy from attacker
                for (let i = 0; i < move.discardCount; i++) {
                    const idx = attacker.energies.findIndex(e => e === move.energyType);
                    if (idx !== -1) {
                        attacker.energies.splice(idx, 1);
                        attackingPlayer.discardPile.push(move.energyType);
                    }
                }
                this.log(`${attacker.name} から${move.energyType}エネルギーを${move.discardCount}個トラッシュ`);
                break;

            case 'cant_attack_next_turn':
                attacker.canAttack = false;
                this.log(`次のターン、${attacker.name}は技を使えない`);
                break;
        }

        return totalDamage;
    }

    retreat(playerId) {
        const player = this.getPlayer(playerId);
        const active = player.active;
        if (!active) throw new Error("ポケモンがいません");

        // Check Status
        if (active.status === 'Paralysis' || active.status === 'Sleep') {
            throw new Error("状態異常で逃げられません！");
        }

        // Check Cost
        const cost = active.data.retreatCost;
        if (active.energies.length < cost) throw new Error("エネルギーが足りません");

        // Discard energies
        for (let i = 0; i < cost; i++) {
            if (active.energies.length > 0) {
                const energy = active.energies.pop();
                player.discardPile.push(energy);
            }
        }

        this.log(`${player.name} は ${cost}個のエネルギーをトラッシュした`);
    }

    switchPokemon(playerId, benchIndex) {
        const player = this.getPlayer(playerId);
        const active = player.active;
        const benchPoke = player.bench[benchIndex];

        if (!benchPoke) throw new Error("ポケモンがいません");

        // Swap
        player.bench[benchIndex] = active;
        player.active = benchPoke;

        // Status conditions cleared for new active
        if (player.active) player.active.status = null;

        this.log(`${player.name} は ${benchPoke.name} と交代した`);
    }

    handleKnockout(owner, pokemon) {
        owner.discardPile.push(pokemon.id); // Add base card
    }

    endTurn() {
        // Status Checks - apply to BOTH players' active Pokemon
        const currentP = this.getPlayer(this.currentTurnPlayerId);
        const otherP = this.getOpponent(this.currentTurnPlayerId);

        // Process status conditions
        [currentP.active, otherP.active].forEach(p => {
            if (!p) return;

            // Poison: 10 damage at end of turn
            if (p.status === 'Poison') {
                p.takeDamage(10);
                this.log(`${p.name} はどくのダメージを受けた (10)。`);
                if (p.currentHp <= 0) {
                    this.log(`${p.name} はどくで倒れた！`);
                }
            }

            // Burn: 20 damage, coin flip to remove
            if (p.status === 'Burn') {
                p.takeDamage(20);
                this.log(`${p.name} はやけどのダメージを受けた (20)。`);
                const flip = Math.random() > 0.5;
                if (flip) {
                    p.status = null;
                    this.log(`${p.name} のやけどが治った。`);
                } else {
                    this.log(`${p.name} はまだやけど状態だ。`);
                }
                if (p.currentHp <= 0) {
                    this.log(`${p.name} はやけどで倒れた！`);
                }
            }

            // Paralysis: removed at end of turn
            if (p.status === 'Paralysis') {
                p.status = null;
                this.log(`${p.name} のまひが治った。`);
            }

            // Sleep: coin flip to wake up
            if (p.status === 'Sleep') {
                const flip = Math.random() > 0.5;
                if (flip) {
                    p.status = null;
                    this.log(`${p.name} は目を覚ました！`);
                } else {
                    this.log(`${p.name} はぐうぐう眠っている...`);
                }
            }

            // Note: Confusion doesn't have end-of-turn effect, only checked when attacking
        });

        // Restore canAttack flags
        if (currentP.active) currentP.active.canAttack = true;
        if (otherP.active) otherP.active.canAttack = true;

        // Switch Turn
        this.turnCount++;
        this.currentTurnPlayerId = otherP.id;
        this.startTurn(this.currentTurnPlayerId);
    }

    // --- Utils ---
    getPlayer(id) {
        return this.player.id === id ? this.player : this.opponent;
    }
    getOpponent(id) {
        return this.player.id === id ? this.opponent : this.player;
    }

    getCardData(id) {
        return CARDS.find(c => c.id === id);
    }
}
