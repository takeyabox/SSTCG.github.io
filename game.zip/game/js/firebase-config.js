// TODO: User must replace this with their own Firebase project configuration
export const firebaseConfig = {
    apiKey: "AIzaSyCgAlA2GEU-tkCro-gG3Y3461MP05Egx2E",
    authDomain: "sstcg-34266.firebaseapp.com",
    databaseURL: "https://sstcg-34266-default-rtdb.firebaseio.com/",
    projectId: "sstcg-34266",
    storageBucket: "sstcg-34266.firebasestorage.app",
    messagingSenderId: "1074065459252",
    appId: "1:1074065459252:web:11a63b1a184dd44242e261"
};
