import { CARDS } from './data/cards.js';
import { firebaseConfig } from './firebase-config.js';
import { GameEngine } from './game/GameEngine.js';
import { FirebaseManager } from './network/FirebaseManager.js';
import { UIManager } from './ui/UIManager.js';

console.log("ポケポケバトル Initializing...");

if (firebaseConfig.apiKey === "YOUR_API_KEY") {
    console.warn("Please update js/firebase-config.js with your actual Firebase configuration!");
}

// Global App State
const appState = {
    user: {
        name: `Guest_${Math.floor(Math.random() * 1000)}`,
        id: `user_${Date.now()}_${Math.floor(Math.random() * 1000)}`
    },
    room: null,
    deck: [], // ID array
    selectedEnergies: ["Water"] // Default
};

// Components
const firebaseManager = new FirebaseManager();
let gameEngine = null;
let uiManager = null;

// DOM Elements
const screenLobby = document.getElementById('lobby-screen');
const screenBattle = document.getElementById('battle-screen');
const inputName = document.getElementById('username');
const inputRoomId = document.getElementById('room-id');
const btnCreateRoom = document.getElementById('btn-create-room');
const btnJoinRoom = document.getElementById('btn-join-room');
const cardSelectionList = document.getElementById('card-selection-list');
const selectedCountSpan = document.getElementById('selected-count');

// Init Default Values
if (inputName) inputName.value = appState.user.name;

// Initialize Deck Builder UI
function initDeckBuilder() {
    console.log("Initializing Deck Builder...", CARDS);
    if (!cardSelectionList) {
        console.error("Card selection list element not found!");
        return;
    }

    // Clear loading text
    cardSelectionList.innerHTML = '';

    if (!CARDS || CARDS.length === 0) {
        cardSelectionList.innerHTML = "カードデータが見つかりません (No Card Data)";
        return;
    }

    CARDS.forEach(card => {
        const el = document.createElement('div');
        el.className = 'card-select-item';
        el.textContent = `${card.name} (HP ${card.hp})`;
        el.dataset.id = card.id;

        el.onclick = () => toggleCardSelection(card.id, el);
        cardSelectionList.appendChild(el);
    });
}

function toggleCardSelection(id, element) {
    // Count how many copies of this card are already in the deck
    const currentCount = appState.deck.filter(c => c === id).length;

    if (currentCount >= 2) {
        // Remove all copies (cycle back to 0)
        appState.deck = appState.deck.filter(c => c !== id);
        element.classList.remove('selected');
        element.classList.remove('selected-2');
        delete element.dataset.count;
    } else if (currentCount === 1) {
        // Add second copy
        if (appState.deck.length >= 20) return alert("最大20枚までです！");
        appState.deck.push(id);
        element.classList.remove('selected');
        element.classList.add('selected-2');
        element.dataset.count = '2';
    } else {
        // Add first copy
        if (appState.deck.length >= 20) return alert("最大20枚までです！");
        appState.deck.push(id);
        element.classList.add('selected');
        element.dataset.count = '1';
    }

    selectedCountSpan.textContent = appState.deck.length;
}

// Networking Callbacks
firebaseManager.onGameStateChange = (roomData) => {
    console.log("Game State Update Recv:", roomData);

    const players = roomData.players || {};
    const playerIds = Object.keys(players);

    // Host Auto-Start Logic
    if (roomData.status === 'waiting' && playerIds.length === 2) {
        if (roomData.host.id === appState.user.id) {
            console.log("Both players ready! Starting game...");
            const myId = appState.user.id;
            const oppId = playerIds.find(id => id !== myId);

            const me = players[myId];
            const them = players[oppId];

            // Initialize Host Engine locally
            gameEngine = new GameEngine(myId, oppId, me.deck, them.deck, me.energies, them.energies);
            gameEngine.initGame();

            // Setup UI for Host
            setupWindowManager();

            // Broadcast Start
            firebaseManager.startGame(gameEngine.toJSON());
        } else {
            document.getElementById('lobby-status').textContent = "ホストがゲームを開始するのを待っています...";
        }
        return;
    }

    // Game Running Logic
    if (roomData.status === 'playing') {
        if (!gameEngine && roomData.gameState) {
            // Client (or Host reconnect) initialization
            console.log("Initializing Game from Network State...");
            const myId = appState.user.id;
            const oppId = playerIds.find(id => id !== myId);

            // For hydration, we use empty arrays as restoreState will overwrite.
            gameEngine = new GameEngine(myId, oppId, [], [], [], []);
            setupWindowManager();

            gameEngine.restoreState(roomData.gameState);
            uiManager.render(roomData.gameState);
        } else if (gameEngine && roomData.gameState) {
            // Update existing game
            gameEngine.restoreState(roomData.gameState);
            uiManager.render(roomData.gameState);
        }

        screenLobby.classList.add('hidden');
        screenBattle.classList.remove('hidden');
    }
};

// Event Listeners for Room Creation/Joining
if (btnCreateRoom) {
    btnCreateRoom.addEventListener('click', async () => {
        if (!validateInput()) return;
        updateUserFromInput();

        try {
            await firebaseManager.createRoom(inputRoomId.value, {
                id: appState.user.id,
                name: appState.user.name,
                deck: appState.deck,
                energies: appState.selectedEnergies
            });
            document.getElementById('lobby-status').textContent = "部屋を作成しました！対戦相手を待っています...";
        } catch (e) {
            alert("エラー: " + e.message);
        }
    });
}

if (btnJoinRoom) {
    btnJoinRoom.addEventListener('click', async () => {
        if (!validateInput()) return;
        updateUserFromInput();

        try {
            await firebaseManager.joinRoom(inputRoomId.value, {
                id: appState.user.id,
                name: appState.user.name,
                deck: appState.deck,
                energies: appState.selectedEnergies
            });
            document.getElementById('lobby-status').textContent = "参加しました！ホストの開始を待っています...";
        } catch (e) {
            alert("エラー: " + e.message);
        }
    });
}

function validateInput() {
    const name = inputName.value.trim();
    const roomId = inputRoomId.value.trim();
    if (!name || !roomId) {
        alert("名前と部屋IDを入力してください！");
        return false;
    }
    if (appState.deck.length !== 20) {
        alert("20枚のカードを選んでください！");
        return false;
    }

    const energyChecks = document.querySelectorAll('input[name="energy"]:checked');
    if (energyChecks.length < 1 || energyChecks.length > 3) {
        alert("エネルギーを1〜3種類選んでください！");
        return false;
    }

    return true;
}

function updateUserFromInput() {
    appState.user.name = inputName.value.trim();
    const energyChecks = document.querySelectorAll('input[name="energy"]:checked');
    appState.selectedEnergies = Array.from(energyChecks).map(c => c.value);
}

function setupWindowManager() {
    if (uiManager) return;
    uiManager = new UIManager(gameEngine, appState.user.id);

    // Hook UI actions to Network
    uiManager.onAction = async () => {
        // Serialize and Push
        const gameState = gameEngine.toJSON();
        await firebaseManager.updateGameState(gameState);
    };
}


// Init
document.addEventListener('DOMContentLoaded', () => {
    try {
        initDeckBuilder();
    } catch (e) {
        console.error("Init Error:", e);
        alert("初期化エラーが発生しました: " + e.message);
    }
});
