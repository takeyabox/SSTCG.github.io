# GitHub Pagesへのデプロイ手順

## 前提条件

- GitHubアカウント
- Gitがインストールされている

## デプロイ手順

### 1. GitHubリポジトリの作成

1. [GitHub](https://github.com)にログイン
2. 右上の「+」→「New repository」をクリック
3. リポジトリ名を入力（例：`pokepoke-battle`）
4. 「Public」を選択
5. 「Create repository」をクリック

### 2. ローカルでGit初期化とプッシュ

このフォルダ（`game`フォルダ）で以下のコマンドを実行：

```powershell
# Gitリポジトリを初期化
git init

# すべてのファイルを追加
git add .

# 最初のコミット
git commit -m "Initial commit - ポケポケバトル完成版"

# GitHubリポジトリをリモートとして追加（URLは自分のリポジトリに変更）
git remote add origin https://github.com/YOUR_USERNAME/pokepoke-battle.git

# メインブランチにプッシュ
git branch -M main
git push -u origin main
```

### 3. GitHub Pagesを有効化

1. GitHubのリポジトリページに移動
2. 「Settings」タブをクリック
3. 左サイドバーから「Pages」を選択
4. 「Source」で「Deploy from a branch」を選択
5. 「Branch」で「main」を選択、フォルダは「/ (root)」を選択
6. 「Save」をクリック

### 4. デプロイ完了を待つ

- 数分後、ページ上部に公開URLが表示されます
- URL形式：`https://YOUR_USERNAME.github.io/pokepoke-battle/`

### 5. ゲームにアクセス

表示されたURLをブラウザで開いてゲームをプレイ！

## 更新方法

ファイルを変更した後：

```powershell
git add .
git commit -m "変更内容の説明"
git push
```

数分後、GitHub Pagesに自動的に反映されます。

## トラブルシューティング

### ページが表示されない
- GitHub Pagesの設定が保存されているか確認
- リポジトリが「Public」になっているか確認
- 数分待ってから再度アクセス

### カードが表示されない
- GitHub Pages上でも正常に動作するはずです
- ブラウザのコンソール（F12）でエラーを確認

### Firebaseエラー
- `js/firebase-config.js`の設定が正しいか確認
- Firebase Realtime Databaseのルールが公開設定になっているか確認

## 重要な注意事項

### ⚠️ Firebase設定について

現在使用しているFirebase設定は共有プロジェクトです。**本番環境では独自のFirebaseプロジェクトを作成することを強く推奨します。**

理由：
- 共有プロジェクトは他のユーザーもアクセス可能
- データが混在する可能性がある
- 使用量制限に達する可能性がある

独自のFirebaseプロジェクトを作成する手順は`README.md`を参照してください。

## カスタムドメインの設定（オプション）

1. GitHub Pagesの設定ページで「Custom domain」にドメインを入力
2. DNSプロバイダーでCNAMEレコードを設定
3. 「Enforce HTTPS」を有効化

詳細は[GitHub Pagesドキュメント](https://docs.github.com/ja/pages/configuring-a-custom-domain-for-your-github-pages-site)を参照。
